<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'kovoors_wp769');

/** MySQL database username */
define('DB_USER', 'kovoors_wp769');

/** MySQL database password */
define('DB_PASSWORD', '.S45f.2h2p');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'rr9mdtrce4zimakuhvvybd3wvrvrmbe1lgugk6ut83pwjk34nqguwecjx9rl85xx');
define('SECURE_AUTH_KEY',  'ywgh3f1xjz3eex8odbuqjhbtogsxnincfrk1ldnlqweza65jytd8vafupyfyo5r2');
define('LOGGED_IN_KEY',    'w0glpby7r3grtcjdjbhylid1qkm88ohruzbhastjvg31kclgfsikdiamjc9cxbp7');
define('NONCE_KEY',        'q7tqckclwmhi4qinpsevmk8i5kotf4iqwomsi1lfi2urpz26vqyszvdmqqj3q1rn');
define('AUTH_SALT',        'amutsytt8q7zvfm3u9ort3vxxe085uwtiqu5bwwestpgl3mznxhhafrzu9decwjp');
define('SECURE_AUTH_SALT', 'yreljvekx13oj3yrpegxdxczopfjtjip98dkoe2neea7lirdie2ugvfsfh6hmpki');
define('LOGGED_IN_SALT',   'jvjuapaxzc48i6hkzacmj75czb44kpxsb5tv1eqhav38owhcv3jbiu5digj6m4mf');
define('NONCE_SALT',       'f8tbj6aaxkk4pogyvvueyohtyws9mdosbolnwsfgahzs1aei0tlvvv6qdsxcxxwn');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpes_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
