<?php
if(isset($_POST['email'])) {
     
    // EDIT THE 2 LINES BELOW AS REQUIRED
    $email_to = "homespriya@gmail.com";
    $email_subject = "Contact Form From Priya Homes";
     
     
    function died($error) {
        // your error code can go here
        echo "We are very sorry, but there were error(s) found with the form you submitted. ";
        echo "These errors appear below.<br /><br />";
        echo $error."<br /><br />";
        echo "Please go back and fix these errors.<br /><br />";
        die();
    }
     
    // validation expected data exists
    if(!isset($_POST['name']) ||
        !isset($_POST['email']) ||
        
	    !isset($_POST['phone']) ||
		!isset($_POST['suggestions'])) 
		{
        died('We are sorry, but there appears to be a problem with the form you submitted.');       
     }
     
    $name = $_POST['name']; // required
	$email = $_POST['email']; // required
    
	$phone = $_POST['phone']; // not required
	$suggestions = $_POST['suggestions']; // required
	
	
	$error_message = "";
	$email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
  if(!preg_match($email_exp,$email)) {
    $error_message .= 'The Email Address you entered does not appear to be valid.<br />';
  }
   if(strlen($error_message) > 0) {
    died($error_message);
  }
    $email_message = "Contact Form details below.\n\n";
     
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
     
    $email_message .= "Name: ".clean_string($name)."\n";
    $email_message .= "Email: ".clean_string($email)."\n";
	
	$email_message .= "Phone: ".clean_string($phone)."\n";
	$email_message .= "Sugesstions: ".clean_string($suggestions)."\n";
	
	
	// create email headers
$headers = 'From: '.$email."\r\n".
'Reply-To: '.$email."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers);  
?>
 
<!-- include your own success html here -->
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Priya Homes - homestay cochin, kerala, kochi, ernakulam, hotels, resorts, safe stay, fully furnished, village facilities, modern aminities, tourist visit foreignerss</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Priya Homes - homestay cochin, kerala, kochi, ernakulam, hotels, resorts, safe stay, fully furnished, village facilities, modern aminities, tourist visit foreigners" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:700,300,600,800,400' rel='stylesheet' type='text/css'>
<script src="js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/common.css" />
<style type="text/css">
<!--
.style42 {color: #FFFFFF}
.style27 {font-family: "Trebuchet MS";
	font-size: 14px;
}
.style46 {font-family: "Trebuchet MS"; font-size: 12px; color: #000000; }
.style50 {color: #000000; font-size: 12px; }
-->
</style><form name="contactform" method="post" action="send_formt_email.php">
</head>
<body>
<!-- header -->
	<div class="header">
		<div class="container">
			<div class="logo">
				<a href="index.html"><img src="images/logo.png" class="img-responsive" alt=""></a>
			</div>
				<div class="head-nav">
					<span class="menu"> </span>
						<ul class="cl-effect-16">
							<li><a href="index.html" data-hover="HOME">home</a></li>
							<li class="active"><a href=" about.html" data-hover="ABOUT US">about us</a></li>
							<li><a href=" facilities.html" data-hover="FACILITIES">facilities</a></li>
							
							<li><a href=" portfolio.html" data-hover="PHOTO GALLERY">photo gallery </a></li>
							<li><a href=" location.html" target="_blank" data-hover="LOCATION">Location </a></li>
							<li><a href=" contact.html" data-hover="CONTACT US">contact us</a></li>
								<div class="clearfix"> </div>
						</ul>
							<!-- script-for-nav -->
						<script>
							$( "span.menu" ).click(function() {
							  $( ".head-nav ul" ).slideToggle(300, function() {
								// Animation complete.
							  });
							});
						</script>
					<!-- script-for-nav --> 
				</div>
					<div class="clearfix"> </div>
		</div>
	</div>
<!-- header -->
<!--start-about-->	
	<div class="about">
		<div class="container">
			<div class="about-main">
				<h3>Testimonials</h3>
				<div class="about-top">
					<div class="col-md-5 about-top-left">
						<img src="images/abt-1.jpg" alt="">
					</div>
					<div class="col-md-7 about-top-right">
						<h4>&nbsp;</h4>
						<p>Your Experience &amp; Suggestions<br>
						  <br>
					  </p>
						<table width="438" align="left">
                          <tr>
                            <td width="36"></td>
                          </tr>
                          <tr>
                            <td  "valign="top"><span class="style27">
                              <label for="name"></label>
                            </span></td>
                            <td width="390" valign="top">&nbsp;</td>
                          </tr>
                          <tr>
                            <td valign="top"><span class="style27">
                              <label for="email"></label>
                            </span></td>
                            <td valign="top">&nbsp;</td>
                          </tr>
                          <tr>
                            <td valign="top"><span class="style46">
                              <label for="phone"></label>
                            </span></td>
                            <td valign="top"><div align="center"><strong>Thank You</strong></div></td>
                          </tr>
                          <tr>
                            <td valign="top"><span class="style27">
                              <label for="message"></label>
                            </span></td>
                            <td valign="top">&nbsp;</td>
                          </tr>
                          <tr>
                            <td style="text-align:center">&nbsp;</td>
                            <td style="text-align:center"><div align="left"></div></td>
                          </tr>
                        </table>
						<p>&nbsp; </p>
						<h4>&nbsp;</h4>
						<h4>&nbsp;</h4>
				  </div>
					<br>
					<br>
					<br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	<!--End-about-->	
	<!--start-advantage-->	
	<div class="advn">
	  <div class="container"></div>
	</div>
	<!--End-advantage-->
	<!--start-team-->
<div class="team"></div>
	<!--end-team-->		

<!-- later -->
<!-- later -->
<!-- footer -->
<div class="footer">
		<div class="container">
			<div class="col-md-3 footer-1">
				<h3>Company</h3>
				<div class="foot-nav">
					<ul>
						<li class="active"><a href="index.html">home</a></li>
						<li><a href=" about.html">about us</a></li>
						<li><a href=" portfolio.html">portfolio</a></li>
						<li><a href=" services.html">services</a></li>
						<li><a href=" contact.html">contact us</a></li>
						<li><a href=" #">Testimonials</a></li>
							<div class="clearfix"> </div>
					</ul>
				</div>
			</div>
			<div class="col-md-3 footer-1">
				<h3>Click To View Other Sites </h3>
				<p><a href="sree.html" target="_blank"><img src="images/sreec.png" width="251" height="41"></a></p>
				<div class="social-ic">
					
                         <p>
							<a href="kerala.html" target="_blank"><img src="images/button.png" width="250" height="41"></a>
                         <div class="clearfix"></div>
						</p>
			  </div>
			</div>
			<div class="col-md-3 footer-1">
				<h3>Priya Homes</h3>
				<p>Near Sreedhareeyam Hospital<br>
Koothattukulam, Kerala <br>
Email : homespriya@gmail.com<br>
Mob: +99612 62624, +97470 33339</p>
		  </div>
			<div class="col-md-3 footer-1">
              <h3>Keerthi Homes</h3>
			  <p>Near Mahadeva Temple </p>
			  <p>Koothattukulam, Kerala<br>
                <a href="http://www.keerthihomes.in">www.keerthihomes.in</a></p>
			  <p> Email : homespriya@gmail.com</p>
			  <p> Mob: + 97470 33339, +99612 62624</p>
		  </div>
			<div class="clearfix"> </div>
			<div class="foot-bottom">
				<p>Copyrights © 2015 Priya Homes. All rights reserved | Powered By <a href="http://www.helloweb.in" target="_blank">Hello Web</a></p>
			</div>
		</div>
</div>
<!-- footer -->
</body>
</html>


<?php
}
?>
